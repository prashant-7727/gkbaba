// File: scripts.js
console.log("Welcome to GKBABA!");
